# Lane Segmentation 2.0 > 2023-03-29 3:09pm
https://universe.roboflow.com/lane-segmentation/lane-segmentation-2.0

Provided by a Roboflow user
License: CC BY 4.0

